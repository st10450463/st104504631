/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package st10450463;

import java.util.Scanner;

/**
 *
 * @author ...
 */
public class Main {

    public static void main(String[] args) {
        
        LogIn login = new LogIn();
        Scanner userInput = new Scanner(System.in);

        int value = 0;
        while(value != 3){
// choose loging in options             
            System.out.println("Do you want to sign up or log in?\n1. Sign Up\n2. Log In\n3. Quit");
                                                                         value = userInput.nextInt();
            switch (value) {
                case 1 -> {
                    // insert your first name 
         System.out.println("Enter your first name:");
                String inputFirstName = userInput.next();
                  login.setFirstName(inputFirstName);
                  
                  
                                 System.out.println("Enter your last name:");
                     String inputLastName = userInput.next();
                    login.setLastName(inputLastName);
                    System.out.println("Enter your username:");
                    String inputUsername = userInput.next();
                    login.setUsername(inputUsername);
                    System.out.println("Enter your password:");
                    String inputPassword = userInput.next();
                    login.setPassword(inputPassword);
                    
                    login.registerUser();
                }
                 case 2 -> {
                   
                                System.out.println("Enter your username:");
             String inputUsername = userInput.next();
                    login.setUsername(inputUsername);
                                System.out.println("Enter your password:");
                    String inputPassword = userInput.next();
                                     login.setPassword(inputPassword);
                    System.out.println(login.returnLoginStatus());
                    
                    if(login.loginUser()){
                        break;
                    }
                }
                case 3 -> {
                    break;
                }
                default -> {
                   
                    System.out.println("Please enter either 1,2 or 3");
                    value = userInput.nextInt();
             }
            }
             }
          }
            }
