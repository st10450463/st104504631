/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package st10450463;


/**
 *
 * @author ...
 */
public class LogIn {
    // username and password complexity

    private String username;
    private String password;
    private String firstName;
    private String lastName;

   
    public String getUsername() {
        return username;
    }

  // Username 
    public void setUsername(String username) {
        this.username = username;
    }

   // Password
    public String getPassword() {
        return password;
    }

    
    public void setPassword(String password) {
        this.password = password;
    }

   
    public String getFirstName() {
        return firstName;
    }

   // fist name 
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

   
    public String getLastName() {
        return lastName;
    }

   
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
   
    public boolean checkUserName() {
        if (username.length() <= 5 && username.contains("_")) {
            System.out.println("Username successfully captured");
            return true;
        } else {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return false;
        }
    }
    // password complexity
    public boolean checkPasswordComplexity() {
        if (password.length() >= 8 && password.matches(".*[A-Z].*") && password.matches(".*[0-9].*") && password.matches(".*[!@#$%^&*()].*")) {
            System.out.println("Password successfully captured");
            return true;
        } else {
            System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
            return false;
        }
    }
    
    //Registers user
    public String registerUser() {
        if (checkUserName() && checkPasswordComplexity()) {
            return "User registered successfully";
        } else {
            return "Registration failed";
        }
    }

   //Logs a user
    public boolean loginUser() {
       //Assuming we have some pre-defined user credentials to compare against: username.equals("valid_username") && password.equals("ValidPassword1!").
        if (getUsername().equals(getUsername()) && getPassword().equals(getPassword())) {
            return true;
        } else {
            return false;
        }
    }

   // Login 
    public String returnLoginStatus() {
        if (loginUser()) {
            return "Welcome " + getFirstName() + " " + getLastName() + ", it is great to see you again!";
        } else {
            return "Username or password incorrect, please try again";
        }
    }
}
