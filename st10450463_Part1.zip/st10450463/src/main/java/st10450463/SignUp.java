/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package st10450463;

import java.util.regex.Pattern;

/**
 *
 * @author ...
 */
public class SignUp {
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^\\w{1,5}_?$");
    private static final Pattern PASSWORD_PATTERN = Pattern.compile("^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+\\-={};':\"\\\\|,.<>\\/?])(?=\\S+$).{8,}$");
    
    private String username;
    private String password;
    private String firstName;
    private String lastName;

    SignUp() {
        throw new UnsupportedOperationException("Not supported yet."); //To change generated methods, choose Tools | Templates.
    }
   
    public String getUsername() {
        return username;
    }

// setupusername    
    public void setUsername(String username) {
        this.username = username;
    }

    // getPassword
    public String getPassword() {
        return password;
    }

   
    public void setPassword(String password) {
        this.password = password;
    }

    // put in FirstName
    public String getFirstName() {
        return firstName;
    }

   
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

   
    public String getLastName() {
        return lastName;
    }

   
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public SignUp(String username, String password, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
    }
 
    public boolean checkUserName() {
        // Check if the username contains an underscore and is no more than 5 characters long
        if (username.length() <= 5 && username.contains("_")) {
            System.out.println("Username successfully captured");
            return true;
        } else {
            System.out.println("Username is incorrect, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return false;
        }
    }
// check password 
    public boolean checkPasswordComplexity() {
        if (password.length() >= 8 && password.matches(".*[A-Z].*") && password.matches(".*[0-9].*") && password.matches(".*[!@#$%^&*()].*")) {
            System.out.println("Password successfully captured");
            return true;
        } else {
            System.out.println("Password is incorrect,password must contains at least 8 characters, a capital letter, number and a special character.");
            return false;
        }
    }
// register user 
    public String registerUser() {
        if (checkUserName() && checkPasswordComplexity()) {
            return "User registered successfully";
        } else {
            return "Registration failed";
        }
    }
}
